<?php include_once 'inc/header.inc.php';

?>
		<title>Dashboard</title>
		<h1>Dashboard</h1>
		<div class="box_container">
			<div class="box">
				<h1>Students</h1>
				<h2><?php echo $st_numbers; ?></h2>
			</div>
			<div class="box">
				<h1>Teachers</h1>
				<h2><?php echo $t_numbers; ?></h2>
			</div>
			<div class="box">
				<h1>Subjects</h1>
				<h2><?php echo $sub_numbers; ?></h2>
			</div>
			<div class="box">
				<h1>Info</h1>
				<h2><?php echo $info_numbers; ?></h2>
			</div>
		</div>
		<div class="contents" style="padding-bottom: 50px;">
			<div class="school_info">
				<div class="each_val">
					<span>Term :</span>  
					<i class="fa fa-spin fa-refresh"></i> <?php echo $schDetails['school_term']." Term"; ?>
				</div>
				<div class="each_val">
					<span>Session :</span>  
					<i class="fa fa-building"></i> <?php echo $schDetails['school_session']; ?>
				</div>
				<div class="each_val">
					<span>School Name :</span>  
					<i class="fa fa-home"></i> <?php echo $schDetails['school_name']; ?>
				</div>
				<div class="each_val">
					<span>School Email :</span>  
					<i class="fa fa-envelope"></i> <?php echo $schDetails['school_email']; ?>
				</div>
				<div class="each_val">
					<span>School Mobile :</span>  
					<i class="fa fa-phone"></i> <?php echo $schDetails['school_tel']; ?>
				</div>
				<div class="each_val">
					<span>School Address :</span>  
					<i class="fa fa-map-marker"></i> <?php echo $schDetails['school_address']; ?>
				</div>
				<div class="each_val">
					<span>School Motto :</span>  
					<i class="fa fa-bullhorn"></i> <?php echo $schDetails['school_motto']; ?>
				</div>
				<div class="each_val">
					<span>School Subjects :</span>  
					<i class="fa fa-book"></i> <?php echo $sub_numbers." Subjects"; ?>
				</div>
				<div class="each_val">
					<span>School Anthem :</span>  
					<i class="fa fa-legal"></i> <?php echo $schDetails['school_anthem']; ?>
				</div>


				<div class="edit_school_info">
					<a href="view-school-info"> <i class="fa fa-pencil"> </i> Edit School Info</a>
				</div>
			</div>
		</div>
	</div>
<?php include_once 'inc/footer.inc.php'; ?>
