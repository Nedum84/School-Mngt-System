 <?php
include("inc/header.inc.php");
if ($status!="principal"){
  header('Location:home.php');
}else{
  $getInfo=mysqli_query($mysqli,"SELECT * FROM news ORDER BY id DESC LIMIT 30");
}
?><title>Send Information</title>
  <div class="left_divs">
    <?php include 'inc/left_menu.inc.php'; ?>
  </div><!-- 
  --><div class="contents">
	<div id="welcome" class="home_welcome">
			<h4>Notifications Center!</h4>
	</div>
    <center>
    	<div class="button_dolder">
          <!-- <button id="addNews"><i class="fa fa-plus"></i> Add News</button> -->
          <button id="addNews2"><i class="fa fa-plus"></i> Add News</button>
	        <button id="notify_teachers"><i class="fa fa-info"></i> Notify Teachers</button>
	        <button id="notify_students"><i class="fa fa-info-circle"></i> Notify Students</button>
	        <button id="sent_notifications"><i class="fa fa-eye"></i> Sent Notifications</button>    		
    	</div>
      <div class="news_cols_wrapper">
      	<h5>News Added!</h5>
      	<?php 
      	while ($row=mysqli_fetch_assoc($getInfo)) {
      		echo '<div class="news_cols" data-id="'.$row['id'].'"><span>'.timer_converter_admin($row['date_uploaded']).'</span> : '.$row['subject'].'</div>';
      	}
      	 ?>
      </div>
    </center>
  </div>
</div>

<?php
include("inc/footer.inc.php");
?>
<script type="text/javascript">
  (function() {
    $(document).ready(function() {
      $(document).on('click','#addNews',function() {
        $('#add_news').show(500);
      });//news to news panel
      $(document).on('click','#addNews2',function() {window.location.href="news-panel";});
	  var form = _("add_news_form");
	  form.addEventListener('submit', function(e) {
	    var ajax = new XMLHttpRequest();
	    ajax.open("POST", "ajax/news.php", true);
	    ajax.onload = function(event) {
	      if (ajax.status == 200 && ajax.readyState == 4) {
	      	if (ajax.responseText=="ok") {
	      		alert('News added succesfully.');
	      		$('#add_news_form')[0].reset();
	      		window.location.reload(true);
	      	}else{
	      		$(".add_news_error").text(ajax.responseText);
	      	}		        
	      } else {$(".add_news_error").text("Error "+ajax.status+" occurred when trying to upload your news.");}
	    };
	    ajax.send(new FormData(form));
	    e.preventDefault();return false;
	  },false);

      $(document).on('click','#notify_teachers',function() {
        $('#notify_teachers_modal').show(500);
      });
	  $('#notify_teacher_button').on('click',function() {
	  	var notify_teachers_textarea=$('#notify_teachers_textarea').val().trim();
	  	$.post('ajax/news.php',{notify_teachers_textarea:notify_teachers_textarea},function(data) {
	  		if (data=="ok") {alert("Teachers notification sent.");$('#notify_teachers_modal').hide();$('.st_teachers_modal textarea,st_teachers_modal input').val("");}
	  		else{$(".notify_teacher_error").text(data);}
	  	});
	  });
	  //student notifications
      $(document).on('click','#notify_students',function() {
        $('#notify_students_modal').show(500);
      });
	  $('#notify_student_button').on('click',function() {
	  	var notify_student_textarea=$('#notify_student_textarea').val().trim();
	  	$.post('ajax/news.php',{notify_student_textarea:notify_student_textarea},function(data) {
	  		if (data=="ok") {alert("Students notification sent.");$('#notify_students_modal').hide();$('.st_teachers_modal textarea,st_teachers_modal input').val("");}
	  		else{$(".notify_student_error").text(data);}
	  	});
	  });
	  //add news image change
    $('.news_image').on('change',function() {
        var ext_array=$('.news_image').val().split('.');
        ext 		=ext_array[(ext_array.length)-1].toLowerCase();
        if ((ext=="png")||(ext=="jpeg")||(ext=="jpg")) {
          $(".add_news_error").text("Image added.");
        }else{
          $(".add_news_error").text("Invalid file formate. Upload jpg or png Image.");
        }
      });

    //view news
    $('.news_cols').on('click',function() {
    	var theId=$(this).attr("data-id");
    	$.post('ajax/news.php',{theId:theId},function(data) {
    		$('#view_news').show(500);
    		$('.news_info_fill').html(data);
    		$('.news_delete_button').attr('id',theId);
    	});
    });
    //delete news
    $('.news_delete_button').on('click',function() {
    	var news_del_id=$(this).attr("id");
    	if (confirm("Delete this news?")) {
	    	$.post('ajax/news.php',{news_del_id:news_del_id},function(data) {
	    		if (data=="ok") {
		    		$('#view_news').hide(500);
		    		window.location.reload(true);
	    		}else{
	    			$('#error_feed').fadeIn(100).text(data).delay(4000).fadeOut(50);
	    		}
	    	});
    	}
    });
    //view sent notifications
      $(document).on('click','#sent_notifications',function() {
      	notification();
      });
      function notification() {
      	var notify_fetch="true";
    	$.post('ajax/news.php',{notify_fetch:notify_fetch},function(data) {
        	$('#sent_n_modal').show(500);
    		$('.sent_n_fill').html(data);
    	});
      }
    //delete sent notifications
    $(document).on('click','.notify_del',function() {
    	var notify_del_id=$(this).attr("id");
    	if (confirm("Delete this Notification?")) {
	    	$.post('ajax/news.php',{notify_del_id:notify_del_id},function(data) {
	    		if (data=="ok") {
		    		notification();
	    		}else{
	    			$('#error_feed').fadeIn(100).text(data).delay(4000).fadeOut(50);
	    		}
	    	});
    	}
    });



    function _(x){
      return document.getElementById(x);
    }




    });
  })();
</script>
<div id="error_feed"></div>
</body>
</html>