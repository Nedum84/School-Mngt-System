(function() {
	$(document).ready(function () {
		$('.contents .curriculum_result_view .cur_res_btn button.view_res').on('click',function() {
			$('.contents .curriculum_result_view .res_cur_view div.curriculum').css('display','none');
			$('.contents .curriculum_result_view .res_cur_view div.result').css('display','block');
		});
		$('.contents .curriculum_result_view .cur_res_btn button.view_cur').on('click',function() {
			$('.contents .curriculum_result_view .res_cur_view div.result').css('display','none');
			$('.contents .curriculum_result_view .res_cur_view div.curriculum').css('display','block');
		});

		  curFeedBack();
		//curriculum feedback
		function curFeedBack() {
			var curFeedTeacher= 'yes';
			$.post('ajax/formteacher-process.php',{curFeedTeacher:curFeedTeacher},function(data) {$('#show_c_uploaded.form_teachers').html(data);})
		}
		$(document).on('click','.c_view',function() {
			var curViewPath=$(this).attr('data-viewPath');
			var type=$(this).attr('data-type');
			window.location.href="feed_back.php?curViewPath="+curViewPath+"&type="+type;
		});
		$(document).on('click','.c_download',function() {
			var curViewPath=$(this).attr('data-viewPath');
			var type=$(this).attr('data-type');
			window.location.href="feed_back.php?curViewPath="+curViewPath+"&type="+type;
		});
		//result feedback
		resFeedBack();
		function resFeedBack() {
			var resFeedTeacher='yes';$.post('ajax/formteacher-process.php',{resFeedTeacher:resFeedTeacher},function(data) {$('.show_r_uploaded.form_teachers').html(data);})
		}//view result
		$(document).on('click','.r_view',function() {
			var teachers_id=$(this).attr('data-teachers_id');
			var class_id=$(this).attr('data-class_id');
			var session_id=$(this).attr('data-session_id');
			var term_id=$(this).attr('data-term_id');
			var subject_id=$(this).attr('data-subject_id');
			window.location.href="view-uploaded-r?teachers_id="+teachers_id+"&class_id="+class_id
			+"&session_id="+session_id+"&term_id="+term_id+"&subject_id="+subject_id;
		});
		$(document).on('click','.approveBtn',function() {
			if (confirm("Approve result?")) {
				var assigned_average=true;$.post('ajax/formteacher-process.php',{assigned_average:assigned_average},
				function(data) {
					$('#error_feed').fadeIn(150).text(data).delay(10000).fadeOut(50);
				});
			}
		});
		$(document).on('click','.assignBtn',function() {
			if (confirm("Assign Position?")) {
				var assigned_position=true;$.post('ajax/formteacher-process.php',{assigned_position:assigned_position},
				function(data) {
					$('#error_feed').fadeIn(150).text(data).delay(10000).fadeOut(50);
				});
			}
		});
		$(document).on('click','.addBtn',function() {
			var addComment=true;$.post('ajax/formteacher-process.php',{addComment:addComment},
				function(data) {
					if (data>0) {
						if (confirm("Add comment to "+data+" Students?")) {
							window.location.href="form-teacher-comment?classDDD=1234";
						}
					}else{
						$('#error_feed').fadeIn(150).text('Result not approved yet.').delay(10000).fadeOut(50);
					}
				});
		});
	});
})();