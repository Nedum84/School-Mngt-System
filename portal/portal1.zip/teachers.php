<?php
include("inc/header.inc.php");
if ($status!="principal"){
  header('Location:home');
}else{
  $count_teachers=mysqli_query($mysqli,"SELECT * FROM teachers ORDER BY teachers_id ");
}
?><title>Teachers</title>
  <div class="left_divs">
    <?php include 'inc/left_menu.inc.php'; ?>
  </div><!-- 
  --><div class="contents">
    <center>
      <div class="edit_header">
        <h4  style="text-transform: uppercase;"><?php echo "&nbsp; teachers in ".$school; ?>
        </h4>
      </div>
      <div class="student_table">
        <table>
          <tr>
            <td>
              Teachers ID
            </td>
            <td>
              Name
            </td>
            <td>
              Mobile No.
            </td>
            <td>
              Class
            </td>
            <td>
              No. of subjects
            </td>
            <td>
              Status 
            </td>
            <td>
              Password
            </td>
          </tr>
          <?php 
          while ($row=mysqli_fetch_assoc($count_teachers)) {
            if ($row['status']=='1') {$t_status="UNBLOCK";}else{$t_status="BLOCK";}
          ?>
          <tr class="editable">
            <td >
              <?php echo strtoupper($row['teachers_id']); ?>
            </td>
            <td >
              <?php echo strtoupper($row['name']); ?>
            </td>
            <td >
              <?php echo $row['mobile_no']; ?>
            </td>
            <td contenteditable="true" data-type="edit_class" data-name="<?php echo $row['name']; ?>" data-r_id='<?php echo $row['teachers_id']; ?>' data-ini='<?php echo $row['class']; ?>'>
              <?php echo strtoupper($row['class']); ?>
            </td>
            <td  contenteditable="true"  data-type="edit_no_of_s" data-r_id='<?php echo $row['teachers_id']; ?>' data-name="<?php echo $row['name']; ?>"  data-ini='<?php echo $row['no_of_subject']; ?>'>
              <?php echo $row['no_of_subject']; ?>
            </td>
            <td class="block_un_block" data-r_id='<?php echo $row['teachers_id']; ?>' data-name='<?php echo strtoupper($row['name']); ?>'>
              <?php echo $t_status; ?>
            </td>
            <td class="reset_password" data-r_id='<?php echo $row['teachers_id']; ?>' data-name='<?php echo strtoupper($row['name']); ?>'>
              <?php echo "RESET PASSWORD"; ?>
            </td>
          </tr>
          <?php             
          }
           ?>
        </table>
        <div class="st_button_div">
        <button id="registerStudent"><i class="fa fa-plus"></i> Register Teacher</button>
        <button id="uploadStudent"><i class="fa fa-upload"></i> Upload Teacher</button>
        </div>

      </div>
    </center>
  </div>
</div>

<?php
include("inc/footer.inc.php");
?>
<script type="text/javascript">
  (function() {
    $(document).ready(function() {
      $(document).on('blur','tr.editable td',function() {
        var type=$(this).attr('data-type').trim();
        var r_Id=$(this).attr('data-r_id').trim();
        var name=$(this).attr('data-name').trim();
        var ini=$(this).attr('data-ini').trim();
        var dValue=$(this).text().trim().toLowerCase();
          if ((type=="edit_class")&&(dValue!=ini)) {
            if (dValue!="") {
              if (confirm("Assign "+name+" as "+dValue+" form teacher?")) {
                edit_teachers(type,r_Id,dValue);
              }              
            }else{
              if (confirm("Remove "+name+" as "+dValue+" form teacher?")) {
                edit_teachers(type,r_Id,dValue);
              }          
            }
          }if ((type=="edit_no_of_s")&&(dValue!=ini)){
            edit_teachers(type,r_Id,dValue);
          }
        function edit_teachers(type,id,value) {
          $.post('ajax/st-process.php',{teacher_edit_type:type,teacher_edit_id:id,teacher_edit_value:value},function(data) {
            if (data!="") {
              $('#error_feed').fadeIn(100).text(data).delay(8000).fadeOut(50);
            }
          });
        }
      });

      //unblock teachers
      $(document).on('click','.block_un_block',function() {
        var t_name=$(this).attr('data-name').trim();
        var t_r_Id=$(this).attr('data-r_id').trim();
        var t_value=$(this).text().trim();
        // alert(value)
        if (confirm(t_value+' '+t_name)) {
            $.post('ajax/st-process.php',{t_r_Id:t_r_Id},function(data) {
            $('#error_feed').fadeIn(100).text(data).delay(2000).fadeOut(50);
          });
        }
      });
      //Reset teachers password
      $(document).on('click','.reset_password',function() {
        var t_name=$(this).attr('data-name').trim();
        var reset_password_id_t=$(this).attr('data-r_id').trim();
        if (confirm("Reset "+ t_name+"\'s Password?")) {
          $.post('ajax/st-process.php',{reset_password_id_t:reset_password_id_t},function(data) {
            $('#error_feed').fadeIn(100).text(data).delay(2000).fadeOut(50);
          });
        }
      });

    $('.t_file_input').on('change',function() {
        var ext_array=$('.t_file_input').val().split('.');
        ext=ext_array[(ext_array.length)-1];
        if (ext=='csv') {         
          $('.warning_s').text('Teachers file selected.')
        }else{
          $('.warning_s').text('Invalid file formate. Upload .csv teachers register file.');
        }
      });
    var form_teachers = _("t_upload_form");
    form_teachers.addEventListener('submit', function(e) {
        var feed_back_st_upload = $(".warning_s");
        var ajax = new XMLHttpRequest();
        ajax.open("POST", "ajax/st-process.php", true);
        ajax.onload = function(event) {
          if (ajax.status == 200 && ajax.readyState == 4) {
            if ((ajax.responseText).substring(0,6)<=500) {
              $('.warning_s').text(ajax.responseText);
              $('#t_upload_form')[0].reset(0);
            }else{
              $('.warning_s').text(ajax.responseText);
            }           
          } else {
              $('.warning_s').text("Error " + ajax.status + " occurred when trying to upload your file.");
            }
        };
        ajax.send(new FormData(form_teachers));
        e.preventDefault();return false;
      },false);

    var form_register_t = _("t_register_form");
    form_register_t.addEventListener('submit', function(e) {
        var ajax = new XMLHttpRequest();
        ajax.open("POST", "ajax/st-process.php", true);
        ajax.onload = function(event) {
          if (ajax.status == 200 && ajax.readyState == 4) {
            if ((ajax.responseText)=="ok") {
              $('.warning_st_r').text("Teacher registered succesfully.");
              $('#t_register_form')[0].reset();
            }else{
              $('.warning_st_r').text(ajax.responseText);
            }           
          } else {
              $('.warning_st_r').text("Error " + ajax.status + " occurred when trying to upload your file.");
            }
        };
        ajax.send(new FormData(form_register_t));
        e.preventDefault();return false;
      },false);

    $('#uploadStudent').on('click',function() {
      $('#t_add_modal').show(500);
    });
    $('#registerStudent').on('click',function() {
      var highest_check_t=true;
      $.post('ajax/st-process.php',{highest_check_t:highest_check_t},function(data) {
        $('#t_register_modal').show(500);
        $('.warning_st_r').text("The last teachers Identity is "+data+".");
      })
    });

    function _(x){
      return document.getElementById(x);
    }


    });
  })();
</script>
<div id="error_feed"></div>
</body>
</html>