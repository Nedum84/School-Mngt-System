<?php 
  die(header('Location:home'));
  echo ("<SCRIPT LANGUAGE='Javascript'> window.location.href='home';</SCRIPT>");
?>