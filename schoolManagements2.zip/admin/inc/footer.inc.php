	<div class="footer">
		<p><?php echo ucfirst($schDetails['school_name']); ?>. &copy; <?php echo date('Y'); ?> All right Reserved</p>
	</div>
</div>
<script type="text/javascript" src="js/sweetalert.js"></script>
<script src="js/sweetalert.min.js"></script>
<script type="text/javascript" src="../portal/js/upload.js"></script>
<!-- vendors -->

	<!-- jQuery -->
	<script src="../js/vendors/jquery/dist/jquery.min.js"></script>
	<!-- Bootstrap -->
	<script src="../js/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
	<!-- FastClick -->
	<script src="../js/vendors/fastclick/lib/fastclick.js"></script>
	<!-- NProgress -->
	<script src="../js/vendors/nprogress/nprogress.js"></script>
	<!-- Datatables -->
	<script src="../js/vendors/datatables.net/js/jquery.dataTables.min.js"></script>
	<script src="../js/vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
	<script src="../js/vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
	<script src="../js/vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
	<script src="../js/vendors/datatables.net-buttons/js/buttons.flash.min.js"></script>
	<script src="../js/vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
	<script src="../js/vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
	<script src="../js/vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"></script>
	<script src="../js/vendors/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
	<script src="../js/vendors/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
	<script src="../js/vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>
	<script src="../js/vendors/datatables.net-scroller/js/datatables.scroller.min.js"></script>
	<script src="../js/vendors/jszip/dist/jszip.min.js"></script>
	<script src="../js/vendors/pdfmake/build/pdfmake.min.js"></script>
	<script src="../js/vendors/pdfmake/build/vfs_fonts.js"></script>
	<!-- Custom Theme Scripts -->
	<script src="../js/vendors/build/js/custom.min.js"></script>   

    <script>
      $(document).ready(function() {
        //close modal
        $(document).on('click','.modal_close',function(e) {
          e.preventDefault();
          $('.modal_wrapper').css({'display':'none'});
          // $('#st_register_form,#st_upload_form,#t_register_form,#t_upload_form,#add_news_form,#notify_st_form,#notify_t_form,#view_uploaded_news,#view_notification,#add_sub_form,#edit_sub_form,form').css('display','none');
          $('.modal_container>form,.modal_container>div').css('display','none');
          
          $('.modal_container form')[0].reset();
          $('.feedbaack').text('');$('.feedbaack').html('');
        });


        //Form handling plugin
        var handleDataTableButtons = function() {
          if ($("#datatable-buttons").length) {
            $("#datatable-buttons").DataTable({
              dom: "Bfrtip",
              buttons: [
                {
                  extend: "copy",
                  className: "btn-sm"
                },
                {
                  extend: "csv",
                  className: "btn-sm"
                },
                {
                  extend: "excel",
                  className: "btn-sm"
                },
                {
                  extend: "pdfHtml5",
                  className: "btn-sm"
                },
                {
                  extend: "print",
                  className: "btn-sm"
                },
              ],
              responsive: true
            });
          }
        };

        TableManageButtons = function() {
          "use strict";
          return {
            init: function() {
              handleDataTableButtons();
            }
          };
        }();

        $('#datatable').dataTable();
        $('#datatable-keytable').DataTable({
          keys: true
        });

        $('#datatable-responsive').DataTable();

        $('#datatable-scroller').DataTable({
          ajax: "js/datatables/json/scroller-demo.json",
          deferRender: true,
          scrollY: 380,
          scrollCollapse: true,
          scroller: true
        });

        var table = $('#datatable-fixed-header').DataTable({
          fixedHeader: true
        });

        TableManageButtons.init();
      });
    </script>
<script type="text/javascript">
(function() {
	$(document).ready(function() {
		function upload(current) {
			var reader = new FileReader();
			reader.onload = function (e) {
				$('#profileImg').attr('src',e.target.result);
			};
			reader.readAsDataURL(current.files[0]);
		}
	});

	//menu addclassShow
  $('.nav_div ul li a').hover(function() {
    $('.nav_div ul li a').removeClass('menu_PaddingSlideShow');
    $(this).addClass('menu_PaddingSlideShow');
  },function() {
    MenuSlide_show();
  });
  MenuSlide_show();
  function MenuSlide_show() {
    $('.nav_div ul li a').removeClass('menu_PaddingSlideShow');
    var url=location.href;
    var split_url=url.split('/');
    var firstVal=split_url[split_url.length-1].split('?');
    var currentUrl=firstVal[0];
    if (currentUrl=='add-info') {
      currentUrl='information';
    }else if(currentUrl=='view-school-info'||currentUrl=='edit-school-info'||currentUrl=='view-school-subjects') {
      currentUrl='dashboard';
    }else if (currentUrl='teachers-edit-results') {
      currentUrl='teachers-upload';
    }
    $('.nav_div ul li a[href='+currentUrl+']').addClass('menu_PaddingSlideShow');
    
  }


        // function print_session(id) {
        //   var restorPage=document.body.innerHTML;
        //   var printContent=document.getElementById(id).innerHTML;
        //   document.body.innerHTML=printContent;
        //   window.print();
        //   document.body.innerHTML=restorPage;
        // }
})();
</script>
<script type="text/javascript" src="nicEditor/nicEdit.js"></script>
<!-- <script type="text/javascript" src="http://js.nicedit.com/nicEdit-latest.js"></script> -->
<div id="error_feed"></div>
<?php include_once 'inc/modals.inc.php'; ?>
</body>
</html>