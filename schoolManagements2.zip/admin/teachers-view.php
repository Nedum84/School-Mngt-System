<?php include_once 'inc/header.inc.php'; 

	
  $count_teachers=mysqli_query($mysqli,"SELECT * FROM teachers ORDER BY teachers_id ");
?>
<title>Teachers</title>
		<div class="contents">
			<center>
				<div class="edit_header">
					<h5>Teachers in  <?php echo "<span>".ucfirst($schDetails['school_name'])."</span>"; ?></h5>
				</div>
				<div class="student_table">
					<table id="datatable-buttons" class="table table-striped table-bordered">
						<thead>
				          <tr>
				            <th>
				              Teachers ID
				            </th>
				            <th>
				              Name
				            </th>
				            <th>
				              Classes
				            </th>
				            <th>
				              Subjects
				            </th>
				            <th>
				              My Class
				            </th>
				            <th>
				              SUB No.
				            </th>
				            <th>
				              Status 
				            </th>
				            <th>
				              Password
				            </th>
				          </tr>
						</thead>
						<?php 
						while ($row=mysqli_fetch_assoc($count_teachers)) {
							if ($row['status']=='1') {$t_status="UNBLOCK";}else{$t_status="BLOCK";}
						?>
						<tr class="editable" style="font-size: .9em">
				            <td >
				              <?php echo strtoupper($row['teachers_id']); ?>
				            </td>
				            <td >
				              <?php echo ucwords($row['name']); ?>
				            </td>
				            <td style="width: 5%;" contenteditable="true" data-type="edit_teaching_class" data-r_id='<?php echo $row['teachers_id']; ?>' data-name="<?php echo ucwords($row['name']); ?>"  data-ini='<?php echo $row['teaching_class']; ?>'>
				              <?php echo ($row['teaching_class']); ?>
				            </td>
				            <td style="width: 5%;" contenteditable="true" data-type="edit_teaching_subject" data-r_id='<?php echo $row['teachers_id']; ?>' data-name="<?php echo ucwords($row['name']); ?>"  data-ini='<?php echo $row['teaching_subject']; ?>'>
				              <?php echo ($row['teaching_subject']); ?>
				            </td>
				            <td contenteditable="true" data-type="edit_class" data-name="<?php echo ucwords($row['name']); ?>" data-r_id='<?php echo $row['teachers_id']; ?>' data-ini='<?php echo $row['class']; ?>'>
				              <?php echo strtoupper($row['class']); ?>
				            </td>
				            <td  contenteditable="true"  data-type="edit_no_of_s" data-r_id='<?php echo $row['teachers_id']; ?>' data-name="<?php echo ucwords($row['name']); ?>"  data-ini='<?php echo $row['no_of_subject']; ?>'>
				              <?php echo $row['no_of_subject']; ?>
				            </td>
				            <td class="block_un_block" data-r_id='<?php echo $row['teachers_id']; ?>' data-name='<?php echo ucwords($row['name']); ?>'>
				              <?php echo $t_status; ?>
				            </td>
				            <td class="reset_password" data-r_id='<?php echo $row['teachers_id']; ?>' data-name='<?php echo ucwords($row['name']); ?>'>
				              <?php echo "RESET"; ?>
				            </td>

						</tr>
						<?php 						
						}
						 ?>
					</table>
			        <div class="st_button_div">
			        <button id="registerStudent"><i class="fa fa-plus"></i> Register Teacher</button>
			        <button id="uploadStudent"><i class="fa fa-upload"></i> Upload Teacher</button>
			        </div>

				</div>
			</center>

		</div>
	</div>
<?php include_once 'inc/footer.inc.php'; ?>
<script type="text/javascript">
	(function() {
		$(document).ready(function() {
			// add teachers class and sub no.
	      $(document).on('blur','tr.editable td',function() {
	        var type=$(this).attr('data-type').trim();
	        var r_Id=$(this).attr('data-r_id').trim();
	        var name=$(this).attr('data-name').trim();
	        var ini=$(this).attr('data-ini').trim();
	        var dValue=$(this).text().trim().toLowerCase();
	        if ((dValue!=ini)) {
	        	if ((type=="edit_class")) {
		            if (dValue!="") {
		              if (confirm("Assign "+name+" as "+dValue+" form teacher?")) {
		                edit_teachers(type,r_Id,dValue);
		              }else{
		              	$(this).text('');
		              }           
		            }else{
		              if (confirm("Remove "+name+" as "+dValue+" form teacher?")) {
		                edit_teachers(type,r_Id,dValue);
		              }        
		            }
		          }else {
		            edit_teachers(type,r_Id,dValue);
		          }
	        }
	          
	        function edit_teachers(type,id,value) {
	          $.post('ajax/students-teachers-process.php',{teacher_edit_type:type,teacher_edit_id:id,teacher_edit_value:value},function(data) {
	            if (data!="") {
	              $('#error_feed').fadeIn(100).html(data).delay(5000).fadeOut(50);
	            }
	          });
	        }
	      });

	      //unblock teachers
	      $(document).on('click','.block_un_block',function() {
	        var t_name=$(this).attr('data-name').trim();
	        var t_r_Id=$(this).attr('data-r_id').trim();
	        var t_value=$(this).text().trim();

	        if (confirm(t_value+' '+t_name)) {
	            $.post('ajax/students-teachers-process.php',{t_r_Id:t_r_Id},function(data) {
	            $('#error_feed').fadeIn(100).text(data).delay(2000).fadeOut(50);
	          });
	        }
	      });
	      //Reset teachers password
	      $(document).on('click','.reset_password',function() {
	        var t_name=$(this).attr('data-name').trim();
	        var reset_password_id_t=$(this).attr('data-r_id').trim();
	        if (confirm("Reset "+ t_name+"\'s Password?")) {
	          $.post('ajax/students-teachers-process.php',{reset_password_id_t:reset_password_id_t},function(data) {
	            $('#error_feed').fadeIn(100).text(data).delay(2000).fadeOut(50);
	          });
	        }
	      });
			$(document).on('change select','#show_set',function() {
				$('#show_set_form').submit();
			});

			$('.t_file_input').on('change',function() {
			  	var ext_array=$('.t_file_input').val().split('.');
			  	ext=ext_array[(ext_array.length)-1];
			  	if (ext=='csv') {		  		
			  		$('.feedback').html('<span class="success">Teachers file selected.</span>')
			  	}else{
			  		$('.feedback').text('Invalid file formate. Upload .csv student file.');
			  	}
			});
			//submiting/upload  TEACHERS .csv
		    var form_teachers = _("t_upload_form");
		    form_teachers.addEventListener('submit', function(e) {
				$('#t_upload_button').attr({'disabled':'false'}).addClass('addOpacity').html('Please Wait <i class="fa fa-spinner fa-spin"></i>');

		        var ajax = new XMLHttpRequest();
		        ajax.open("POST", "ajax/students-teachers-process.php", true);
		        ajax.onload = function(event) {
		          if (ajax.status == 200 && ajax.readyState == 4) {
				      	$('#t_upload_button').removeAttr('disabled').removeClass('addOpacity').html('<i class="fa fa-upload"></i><span> Register</span>');

				      	$('.feedback').html(ajax.responseText);
			      		$('#t_upload_form')[0].reset();
			      		if (ajax.responseText.indexOf('registered')!=-1) {
				      		setTimeout(window.location.reload(true),4000);		      			
				      	}    
		          } else {
		              $('.feedback').text("Error " + ajax.status + " occurred when trying to upload your file.");
		            }
		        };
		        ajax.send(new FormData(form_teachers));
		        e.preventDefault();return false;
		      },false);	
			//register a teacher
		    var form_register_t = _("t_register_form");
		    form_register_t.addEventListener('submit', function(e) {
		    	getTId($('#register_t_year').val());
		        var ajax = new XMLHttpRequest();
		        ajax.open("POST", "ajax/students-teachers-process.php", true);
		        ajax.onload = function(event) {
		          if (ajax.status == 200 && ajax.readyState == 4) {
			      	if (ajax.responseText.indexOf('successfully')!=-1) {
			      		$('.feedback').html(ajax.responseText);
			      		$('#t_register_form')[0].reset();		      			
			      	}else{
			      		$('.feedback').html(ajax.responseText);
			      	}	        
		          } else {
		              $('.feedback').text("Error " + ajax.status + " occurred when trying to upload your file.");
		            }
		        };
		        ajax.send(new FormData(form_register_t));
		        e.preventDefault();return false;
		    },false);

			//upload teachers
			$(document).on('click','#uploadStudent',function() {
				$('.modal_wrapper').css({'display':'block'});
				$('#t_upload_form').show(500);
			});
			$(document).on('keyup change focus','#register_t_year',function() {
				var t_Year=$(this).val();
				getTId(t_Year);
			});
			function getTId(t_Year) {
				$.post('ajax/students-teachers-process.php',{t_Year:t_Year},function(data) {
					$('#register_t_id').val(data);
				});
			}
			// register A teacher 
			$(document).on('click','#registerStudent',function() {
				$('.modal_wrapper').css({'display':'block'});
				$('#t_register_form').show(500);
			});

			function _(x){
				return document.getElementById(x);
			}


		});
	})();
</script>
