
<?php
include('partials/pagesheader.php');
?>
	<!-- //header -->
	<h2>About Us</h2>
	</div>
<!-- //banner -->
<!-- team -->
<div class="team">
			<div class="container">
			<h5 class="title-w3">Our Team</h5>
			<p class="head-w3-agileits">Masagni dolores eoquie voluptaquisquam estqui dolorem .</p>
			<div class="team-grids">
					<div class="item">
						<div class="team-info">
							<img src="images/t1.jpg" alt="" />
							<div class="team-caption"> 
								<div class="agileits-w3layouts">
									<h4>Adney</h4>
									<p>Fusce laoreet</p>
								</div>
								<ul>
									<li><a href="#"><i class="fa fa-facebook"></i></a></li>
									<li><a href="#"><i class="fa fa-twitter"></i></a></li>
									<li><a href="#"><i class="fa fa-rss"></i></a></li>
								</ul>
								<div class="clearfix"> </div>		
							</div>
						</div>	
					</div>
					<div class="item">
						<div class="team-info">
							<img src="images/t2.jpg" alt="" />
							<div class="team-caption"> 
								<div class="agileits-w3layouts">
									<h4>Helen Mitchell</h4>
									<p>Lorem ipsum</p>
								</div>
								<ul>
									<li><a href="#"><i class="fa fa-facebook"></i></a></li>
									<li><a href="#"><i class="fa fa-twitter"></i></a></li>
									<li><a href="#"><i class="fa fa-rss"></i></a></li>
								</ul>
								<div class="clearfix"> </div>		
							</div>
						</div>	
					</div>
					<div class="item">
						<div class="team-info">
							<img src="images/t3.jpg" alt="" />
							<div class="team-caption"> 
								<div class="agileits-w3layouts">
									<h4>Aenean sed</h4>
									<p>Nunc tincidunt</p>
								</div>
									<ul>
									<li><a href="#"><i class="fa fa-facebook"></i></a></li>
									<li><a href="#"><i class="fa fa-twitter"></i></a></li>
									<li><a href="#"><i class="fa fa-rss"></i></a></li>
								</ul>
								<div class="clearfix"> </div>		
							</div>
						</div>	
					</div>
					<div class="item">
						<div class="team-info">
							<img src="images/t4.jpg" alt="" />
							<div class="team-caption"> 
								<div class="agileits-w3layouts">
									<h4>William</h4>
									<p>Phasellus magna</p>
								</div>
								<ul>
									<li><a href="#"><i class="fa fa-facebook"></i></a></li>
									<li><a href="#"><i class="fa fa-twitter"></i></a></li>
									<li><a href="#"><i class="fa fa-rss"></i></a></li>
								</ul>
								<div class="clearfix"> </div>		
							</div>
						</div>
					</div>
					
			</div>
		</div>
	</div>		
<!-- //team -->
 
<!--about-->
<!-- agile_testimonials -->
<div class="test" id="clients">
	<div class="container">
	<h5 class="title-w3">Our Customers Says</h5>
			<p class="head-w3-agileits">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor</p>
		<div class=" test-gr">
					<div class=" test-gri1">
					 <div id="owl-demo2" class="owl-carousel">
							<div class="agile">
							   	<div class="col-md-6 test-grid">
							   		<div class="test-grid1">
										<img src="images/1.jpg" alt="" class="img-r">
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis.
										Lorem ipsum dolor .</p>
										<h4>Andery</h4>
										<span>Lorem Ipsum</span>
									</div>	
								</div>	
									<div class="col-md-6 test-grid">
							   		<div class="test-grid1">
										<img src="images/2.jpg" alt="" class="img-r">
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis.
										Lorem ipsum dolor.</p>
										<h4>Bryan</h4>
										<span>Lorem Ipsum</span>
									</div>	
								</div>	
								<div class="clearfix"></div>
							</div>
							<div class="agile">
							   	<div class="col-md-6 test-grid">
							   		<div class="test-grid1">
										<img src="images/3.jpg" alt="" class="img-r">
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis.
										Lorem ipsum dolor.</p>
										<h4>Andery</h4>
										<span>Lorem Ipsum</span>
									</div>	
								</div>	
									<div class="col-md-6 test-grid">
							   		<div class="test-grid1">
										<img src="images/1.jpg" alt="" class="img-r">
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis.
										Lorem ipsum dolor .</p>
										<h4>Bryan</h4>
										<span>Lorem Ipsum</span>
									</div>	
								</div>	
								<div class="clearfix"></div>
							</div>
							<div class="agile">
							   	<div class="col-md-6 test-grid">
							   		<div class="test-grid1">
										<img src="images/2.jpg" alt="" class="img-r">
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis.
										Lorem ipsum dolor .</p>
										<h4>williams</h4>
										<span>Lorem Ipsum</span>
									</div>	
								</div>	
									<div class="col-md-6 test-grid">
							   		<div class="test-grid1">
										<img src="images/3.jpg" alt="" class="img-r">
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis.
										Lorem ipsum dolor .</p>
										<h4>Jack</h4>
										<span>Lorem Ipsum</span>
									</div>	
								</div>	
								<div class="clearfix"></div>
							</div>					
					</div>
				</div>	
		</div>
	</div>
</div>
<!-- //agile_testimonials -->
<!-- Footer -->
<div class="w3l_footer">
		<div class="container">
			
			<div class="w3ls_footer_grids">
				
				<div class="w3ls_footer_grid">
					<div class="col-md-4 w3ls_footer_grid_left">
						<div class="w3ls_footer_grid_leftl">
							<i class="fa fa-map-marker" aria-hidden="true"></i>
						</div>
						<div class="w3ls_footer_grid_leftr">
							<h4>Location</h4>
							<p>Sparks, NV 89434 USA</p>
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="col-md-4 w3ls_footer_grid_left">
						<div class="w3ls_footer_grid_leftl">
							<i class="fa fa-envelope" aria-hidden="true"></i>
						</div>
						<div class="w3ls_footer_grid_leftr">
							<h4>Email</h4>
							<a href="mailto:info@example.com">info@example.com</a>
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="col-md-4 w3ls_footer_grid_left">
						<div class="w3ls_footer_grid_leftl">
							<i class="fa fa-phone" aria-hidden="true"></i>
						</div>
						<div class="w3ls_footer_grid_leftr">
							<h4>Call Us</h4>
							<p>(+000) 003 003 0052</p>
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="clearfix"> </div>
				</div>
			</div>
		</div>
</div>
<?php
include('partials/footer.php');
?>