<?php
include("partials/header.php")
?>
	<!-- //header -->
	<!-- banner-text -->
		<div class="banner-text"> 
			<div class="callbacks_container">
				<ul class="rslides" id="slider3">
					<li>
						<div class="slider-info">
							<h3>what you can imagine we can create.</h3>
							<p> We work on the forefront of innovation and technology.</p>
						</div>
						
					</li>
					<li>
					
						<div class="slider-info">
							 <h3>SOLVE CHALLENGES OF FIELD SERVICE WITH MOBILITY</h3>
							<p>Imagine the possibilities of what we can do for u.</p>
						</div>
					
					</li>
					<li>
						
						<div class="slider-info">
							 <h3>what you can imagine we can create.</h3>
							<p>We work on the forefront of innovation and technology.</p>
						</div>
						
					</li>
					<li>
						
						<div class="slider-info">
							 <h3>SOLVE CHALLENGES OF FIELD SERVICE WITH MOBILITY</h3>
							<p> Imagine the possibilities of what we can do for u.</p>
						</div>
						
					</li>

				</ul>
				
			</div>
			<div class="clearfix"></div>	
		</div>
	</div>
<!-- //banner -->

<!-- //about -->
<div class="about">
	<div class="container">
		<h5 class="title-w3">About us</h5>
			<p class="head-w3-agileits">We build the bridge between the world of ideas and the delivery of products.</p>
		<div class="about-head">
			<div class="col-md-10 col-md-offset-1 ab-head">
				<p><span>Vivvaa Professional Services</span> is a multi-competency enterprise transformation and technology-consulting firm that combines 
					expertise and capabilities across many industries and business functions to deliver superior value to its clients. 
					Vivvaa Professionals collaborates with its clients, both in the private and public sectors, to build high performance enterprises
				</p>	
			</div>
			
		<div class="clearfix"> </div>
		</div>
	</div>
</div>
<!--about-->

	<!--services-->
	<div class="services-w3layouts" id="services">
		<div class="container ">
			<h5 class="title-w3" id="serve" >Services</h5>
			<p class="head-w3-agileits" id="serve2">We build the bridge between the world of ideas and the delivery of products.</p>
			<div id="horizontalTab">
					<ul class="resp-tabs-list">
					<li>
						<div class="work-row-grids wow bounceIn animated" data-wow-delay=".5s" style="visibility: visible; -webkit-animation-delay: .5s;">
						<div class="work-grids-img">
							<span class="glyphicon glyphicon-check" aria-hidden="true"></span>
						</div>	
						<div class="caption work-captn">
							<h4>Software Development</h4>
							<p>We enable organizations drive excellence in IT Operations, 
							and seamlessly integrate data for increased profitability across all areas of operations.Our solutions are designed to suit your needs,</p>						
						 </div>
						 <div class="clearfix"> </div>
						</div>
					</li>
					<li>
						<div class="work-row-grids wow bounceIn animated" data-wow-delay=".5s" style="visibility: visible; -webkit-animation-delay: .5s;">
							<div class="work-grids-img">
								<span class="glyphicon glyphicon-wrench" aria-hidden="true"></span>
							</div>	
							<div class="caption work-captn">
								<h4>Managed Services</h4>
								<p>Associate with Vivvaa's proficiency and market leadership as a managed services partner to give your business a competitive edge,
								improve your business for innovation and growth while driving bottom-line benefits.
									</p>						
							 </div>
							 <div class="clearfix"> </div>
						</div>
					</li>
					<li>
						<div class="work-row-grids wow bounceIn animated" data-wow-delay=".5s" style="visibility: visible; -webkit-animation-delay: .5s;">
							<div class="work-grids-img">
								<span class="glyphicon glyphicon-thumbs-up" aria-hidden="true"></span>
							</div>	
							<div class="caption work-captn">
								<h4>IT and Business Consulting</h4>
								<p>We drive the re-evaluation and redesign of the IT environment ensuring a strategic alignment with your business goals,we act a piece set to 
									making you actualize your dreams .</p>						
							 </div>
							 <div class="clearfix"> </div>
						</div>
					</li>
					<li>
						<div class="work-row-grids wow bounceIn animated" data-wow-delay=".5s" style="visibility: visible; -webkit-animation-delay: .5s;">
						<div class="work-grids-img">
							<span class="glyphicon glyphicon-compressed" aria-hidden="true"></span>
						</div>	
						<div class="caption work-captn">
							<h4>Website Development</h4>
							<p>We have a proven track record of designing and developing high quality custom web-sites and solutions that promotes a superior customer experience for clients.</p>						
						 </div>
						 <div class="clearfix"> </div>
						</div>
					</li>
					</ul>
					<div class="resp-tabs-container">
					<div class="tab1">
						<div class="col-md-6 services-img-w3-agile">
						</div>
						
						<div class="col-md-6 services-right-agileits">
								<h4>Useful Information</h4>
									<p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. 
										Quisquam suscipit facilis facere placeat sunt culpa, aliquid 
										sapiente vitae debitis maiores?
										>Lorem ipsum dolor sit amet consectetur, adipisicing elit. 
										Quisquam suscipit facilis facere placeat sunt culpa, aliquid 
										sapiente vitae debitis maiores?
									</p>
						</div>
									
					
					</div>
					
					<div class="tab2">
					<h5>Managed Services</h5>
					<h6>We have built an enviable reputation in consumer goods, heavy industry, high-tech, manufacturing, recreational vehicle, and transportation sectors.</h6>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis suscipit et dui ut cursus. Ut tortor nisi, congue quis orci at, posuere mattis est. Nunc sollicitudin nisi lorem, eget aliquet leo scelerisque eu. Cras placerat, ligula nec bibendum aliquam, nibh massa venenatis leo, at convallis sem est a sapien.</p>
					</div>

					<div class="tab3">
					<h5>IT and Business Consulting</h5>
					<h6>We have built an enviable reputation in consumer goods, heavy industry, high-tech, manufacturing, recreational vehicle, and transportation sectors.</h6>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis suscipit et dui ut cursus. Ut tortor nisi, congue quis orci at, posuere mattis est. Nunc sollicitudin nisi lorem, eget aliquet leo scelerisque eu. Cras placerat, ligula nec bibendum aliquam, nibh massa venenatis leo, at convallis sem est a sapien.</p>
					</div>
					
					<div class="tab4">
							<div class="col-md-6 services-img-w3-agile">
							</div>
							<div class="col-md-6 services-right-agileits">
								<h4>Useful Information</h4>
									<p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. 
										Quisquam suscipit facilis facere placeat sunt culpa, aliquid 
										sapiente vitae debitis maiores?
										>Lorem ipsum dolor sit amet consectetur, adipisicing elit. 
										Quisquam suscipit facilis facere placeat sunt culpa, aliquid 
										sapiente vitae debitis maiores?
									</p>
							</div>
						</div>
					</div>
			</div>
		</div>
	</div>	
	<!--//services-->


<!--Blogs -->
		<div class="blogs" id="works">
		<div class="container">
		    <h5 class="title-w3">Some of Our Works</h5>
			<p class="head-w3-agileits">We build the bridge between the world of ideas and the delivery of products.</p>
			<div class="inst-grids">
					<a href="single.php"><div class="col-md-3 blog-gd-w3ls">
						<img src="images/blog3.jpg" alt="blog-image">
						<div class="date-w3">
							<h4>2017</h4>
						</div>
						<div class="blog-description-w3agile">
							<h5>Nunc sodales sodales felis</h5>
						 </div>
					</div></a>
					<a href="single.php"><div class="col-md-3 blog-gd-w3ls">
						<img src="images/blog4.jpg" alt="blog-image">
						<div class="date-w3">
							<h4>2016</h4>
						</div>
						<div class="blog-description-w3agile">
							<h5>Nunc sodales sodales felis</h5>
						 </div>
					</div></a>
					<a href="single.php"><div class="col-md-3 blog-gd-w3ls last">
						<img src="images/blog2.jpg" alt="blog-image">
						<div class="date-w3">
							<h4>2015</h4>
						</div>
						<div class="blog-description-w3agile">
							<h5>Nunc sodales sodales felis </h5>
						 </div>
					</div></a>
					<a href="single.php"><div class="col-md-3 blog-gd-w3ls last">
						<img src="images/blog1.jpg" alt="blog-image">
						<div class="date-w3">
							<h4>2014</h4>
						</div>
						<div class="blog-description-w3agile">
							<h5>Nunc sodales sodales felis</h5>
						 </div>
					</div></a>

					<div class="clearfix"> </div>		
				</div>

		</div>
	</div>
	<!--//Blogs -->

<?php
include('partials/footer.php');
?>