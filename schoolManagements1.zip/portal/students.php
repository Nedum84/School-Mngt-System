<?php
include("inc/header.inc.php");
if ($status!="principal"){
	header('Location:home');
}else{
	if (isset($_GET['show_set'])) {
		$show_set=$_GET['show_set'];
	}else{
		$show_set="all";
	}
	if ($show_set!="all") {
		$count_students=mysqli_query($mysqli,"SELECT * FROM students WHERE class LIKE '%".$show_set."%'");
	}else{
		$count_students=mysqli_query($mysqli,"SELECT * FROM students ORDER BY class ");
	}
}
?>	<title>Students</title>
	<div class="left_divs">
		<?php include 'inc/left_menu.inc.php'; ?>
	</div><!-- 
	--><div class="contents">
		<center>
			<div class="edit_header">
				<h4  style="text-transform: uppercase;"><?php echo $show_set."&nbsp; students in ".$school; ?>
				</h4>
				<form method="get" id="show_set_form"><select name="show_set" id="show_set">		
				<?php 
				if (isset($_GET['show_set'])&&$_GET['show_set']!='all') {
					echo '<option value="'.$_GET['show_set'].'">'.strtoupper($_GET['show_set']).' STUDENTS</option>';
				}else{
					echo '<option value="all">FILTER</option>';
				}
				 ?>
				<option value="all">ALL STUDENTS</option>
				<option value="jss1">JSS1 STUDENTS</option>
				<option value="jss2">JSS2 STUDENTS</option>
				<option value="jss3">JSS3 STUDENTS</option>
				<option value="sss1">SSS1 STUDENTS</option>
				<option value="sss2">SSS2 STUDENTS</option>
				<option value="sss3">SSS3 STUDENTS</option>
				</select></form>
			</div>
			<div class="student_table">
				<table>
					<tr>
						<td>
							Student ID
						</td>
						<td>
							Name
						</td>
						<td>
							Class
						</td>
						<td>
							Email
						</td>
						<td>
							Status 
						</td>
						<td>
							Reset Password
						</td>
					</tr>
					<?php 
					while ($row=mysqli_fetch_assoc($count_students)) {
						if ($row['status']=='1') {$st_status="UNBLOCK";}else{$st_status="BLOCK";}
					?>
					<tr class="editable">
						<td >
							<?php echo strtoupper($row['st_id']); ?>
						</td>
						<td >
							<?php echo strtoupper($row['name']); ?>
						</td>
						<td >
							<?php echo strtoupper($row['class']); ?>
						</td>
						<td >
							<?php echo $row['email']; ?>
						</td>
						<td class="block_un_block" data-r_id='<?php echo $row['st_id']; ?>' data-name='<?php echo strtoupper($row['name']); ?>'>
							<?php echo $st_status; ?>
						</td>
						<td class="reset_password" data-r_id='<?php echo $row['st_id']; ?>' data-name='<?php echo strtoupper($row['name']); ?>'>
							<?php echo "RESET PASSWORD"; ?>
						</td>
					</tr>
					<?php 						
					}
					 ?>
				</table>
				<div class="st_button_div">
				<button id="registerStudent"><i class="fa fa-plus"></i> Register Student</button>
				<button id="uploadStudent"><i class="fa fa-upload"></i> Upload Student</button>
				</div>

			</div>
		</center>
	</div>
</div>

<?php
include("inc/footer.inc.php");
?>
<script type="text/javascript">
	(function() {
		$(document).ready(function() {
			$(document).on('click','.block_un_block',function() {
				var st_name=$(this).attr('data-name').trim();
				var st_r_Id=$(this).attr('data-r_id').trim();
				var st_value=$(this).text().trim();
				// alert(value)
				if (confirm(st_value+' '+st_name)) {
						$.post('ajax/st-process.php',{st_r_Id:st_r_Id},function(data) {
						$('#error_feed').fadeIn(100).text(data).delay(2000).fadeOut(50);
					});
				}
			});
			//Reset student password
			$(document).on('click','.reset_password',function() {
				var st_name=$(this).attr('data-name').trim();
				var reset_password_id=$(this).attr('data-r_id').trim();
				if (confirm("Reset "+ st_name+"\'s Password?")) {
					$.post('ajax/st-process.php',{reset_password_id:reset_password_id},function(data) {
						$('#error_feed').fadeIn(100).text(data).delay(2000).fadeOut(50);
					});
				}
			});
			$(document).on('change select','#show_set',function() {
				$('#show_set_form').submit();
			});

		$('.st_file_input').on('change',function() {
		  	var ext_array=$('.st_file_input').val().split('.');
		  	ext=ext_array[(ext_array.length)-1];
		  	if (ext=='csv') {		  		
		  		$('.warning_s').text('Student file selected.')
		  	}else{
		  		$('.warning_s').text('Invalid file formate. Upload .csv student file.');
		  	}
		  });
		var form_student = _("st_upload_form");
		form_student.addEventListener('submit', function(e) {
		    var feed_back_st_upload = $(".warning_s");
		    var ajax = new XMLHttpRequest();
		    ajax.open("POST", "ajax/st-process.php", true);
		    ajax.onload = function(event) {
		      if (ajax.status == 200 && ajax.readyState == 4) {
		      	if ((ajax.responseText).substring(0,6)=="Result") {
		      		$('.warning_s').text(ajax.responseText);
		      		$('#st_upload_form').reset(true);
		      	}else{
		      		$('.warning_s').text(ajax.responseText);
		      	}		        
		      } else {
		      		$('.warning_s').text("Error " + ajax.status + " occurred when trying to upload your file.");
		      	}
		    };
		    ajax.send(new FormData(form_student));
		    e.preventDefault();return false;
		  },false);

		var form_register_st = _("st_register_form");
		form_register_st.addEventListener('submit', function(e) {
		    var ajax = new XMLHttpRequest();
		    ajax.open("POST", "ajax/st-process.php", true);
		    ajax.onload = function(event) {
		      if (ajax.status == 200 && ajax.readyState == 4) {
		      	if ((ajax.responseText)=="ok") {
		      		$('.warning_st_r').text("Student registered succesfully.");
		      		$('#st_register_form')[0].reset();
		      	}else{
		      		$('.warning_st_r').text(ajax.responseText);
		      	}		        
		      } else {
		      		$('.warning_st_r').text("Error " + ajax.status + " occurred when trying to upload your file.");
		      	}
		    };
		    ajax.send(new FormData(form_register_st));
		    e.preventDefault();return false;
		  },false);

		$('#uploadStudent').on('click',function() {
			$('#st_add_modal').show(500);
		});
		$('#registerStudent').on('click',function() {
			var highest_check=true;
			$.post('ajax/st-process.php',{highest_check:highest_check},function(data) {
				$('#st_register_modal').show(500);
				$('.warning_st_r').text("The last student Identity is "+data+".");
			})
		});

		function _(x){
			return document.getElementById(x);
		}


		});
	})();
</script>
<div id="error_feed"></div>
</body>
</html>