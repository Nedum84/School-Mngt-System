<?php 

require_once 'functions.inc.php';
 ?>
 <!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="css/styles.css">
	<link rel="stylesheet" type="text/css" href="css/user-register.css">
	<link rel="stylesheet" type="text/css" href="css/add-post.css">
	<link rel="stylesheet" type="text/css" href="css/students-teachers-view.css">
	<link rel="stylesheet" type="text/css" href="css/modals.inc.css">
	<link rel="stylesheet" type="text/css" href="css/information.css">
	<link rel="stylesheet" type="text/css" href="../portal/css/upload.css">
	<link rel="stylesheet" type="text/css" href="../portal/css/edit-results.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
  	<link href="css/font-awesome.css" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" href="css/sweetalert.css">
	<link href="https://fonts.googleapis.com/css?family=Droid+Serif|Lora|Noto+Sans|Nunito|Roboto|Saira|Saira+Extra+Condensed|Ubuntu" rel="stylesheet">


  <!-- vendors -->
    <!-- Bootstrap -->
    <link href="../js/vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../js/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- Datatables -->
    <link href="../js/vendors/datatables.net-bs/css/dataTables.bootstrap.min.css" rel="stylesheet">
    <link href="../js/vendors/datatables.net-buttons-bs/css/buttons.bootstrap.min.css" rel="stylesheet">
    <link href="../js/vendors/build/css/custom.css" rel="stylesheet">

    
	<script type="text/javascript" src="js/jquery.js"></script>
</head>
<body>
<div class="container_div">
	<div class="header_div">
		<h1><img src="../images/logo.jpg"><?php echo ucfirst($schDetails['school_name']); ?></h1>
	</div>
	<div class="nav_div">
		<ul>
			<li>
				<a href="dashboard">
					<i class="fa fa-home"></i> Dasboard <i class="fa fa-angle-right"></i>
				</a>
			</li>
			<li>
				<a href="students-view">
					<i class="fa fa-users"></i> Students <i class="fa fa-angle-right"></i>
				</a>
			</li>
			<li>
				<a href="teachers-view">
					<i class="fa fa-diamond"></i> Teachers <i class="fa fa-angle-right"></i>
				</a>
			</li>
			<li>
				<a href="teachers-upload">
					<i class="fa fa-upload"></i> Teachers Upload <i class="fa fa-angle-right"></i>
				</a>
			</li>
			<li>
				<a href="result-sheet">
					<i class="fa fa-print"></i> Result Sheet <i class="fa fa-angle-right"></i>
				</a>
			</li>
			<li>
				<a href="information">
					<i class="fa fa-info"></i> Information <i class="fa fa-angle-right"></i>
				</a>
			</li>
			<li>
				<a href="user-register">
					<i class="fa fa-certificate"></i> Register Staff  <i class="fa fa-angle-right"></i>
				</a>
			</li>
			<li>
				<a href="process/logout">
					<i class="fa fa-sign-out"></i> Logout <i class="fa fa-angle-right"></i>
				</a>
			</li>
		</ul>
		<p>Logged in as: <?php echo $user_id; ?></p>
		<div class="users">
			<div class="user_pics" style="background-image: url(<?php if(isset($passport)){echo("../portal/upload/passport-upload/".$passport);} ?>);">
				
			</div>
			<p><?php echo $name; ?></p>
			<p>Access Level: <?php echo $user_level; ?></p>
		</div>
	</div>
	<div class="right">
