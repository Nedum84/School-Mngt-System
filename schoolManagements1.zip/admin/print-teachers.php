<?php include_once 'inc/header.inc.php'; 

	
	if (isset($_GET['f'])) {
		if (isset($_GET['u'])&&(!empty($_GET['u']))) {
			$show_set=$_GET['u'];
		}else{
			$show_set=$_GET['f'];
		}		
	}else{
		$show_set="all";
	}
	if ($show_set!="all") {
		$count_students=mysqli_query($mysqli,"SELECT * FROM teachers WHERE class LIKE '%".$show_set."%'");
	}else{
		$count_students=mysqli_query($mysqli,"SELECT * FROM teachers ORDER BY teachers_id ");
	}
?>
		<title>..::<?php echo strtoupper($show_set)." TEACHERS"; ?></title>
		<div class="contents">
			<center>
				<div class="edit_header">
					<h5>
						<?php echo $show_set; ?> Teachers in  <?php echo "<span>".ucfirst($schDetails['school_name'])."</span>"; ?>							
					</h5>
				<button id="print_class"><i class="fa fa-print"></i> PRINT</button>
				</div>
				<div class="student_table" id="student_table">
					<table id="datatable-buttons" class="table table-striped table-bordered">
						<thead>							
							<tr>
								<th>
									S/N
								</th>
								<th>
									Teachers REG NO.
								</th>
								<th>
									Name
								</th>
							</tr>
						</thead>
						<tbody>
						<?php 
						$x=1;
						while ($row=mysqli_fetch_assoc($count_students)) {
							if ($row['status']=='1') {$st_status="UNBLOCK";}else{$st_status="BLOCK";}
							
						?>
						<tr class="editable">
							<td >
								<?php echo $x; ?>
							</td>
							<td >
								<?php echo strtoupper($row['teachers_id']); ?>
							</td>
							<td >
								<?php echo ucwords($row['name']); ?>
							</td>
						</tr>
						<?php 						
						$x++;}
						 ?>
						</tbody>
					</table>

				</div>
			</center>

		</div>
	</div>
<?php include_once 'inc/footer.inc.php'; ?>
<script type="text/javascript">
	(function() {
		$(document).ready(function() {      

			$(document).on('click','#print_class',function() {
		        window.print();
			});
		});
	})();
</script>
